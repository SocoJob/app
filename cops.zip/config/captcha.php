<?php

return [
    'key' => env('GOOGLE_RECAPTCHA_KEY'),
    'secret' => env('GOOGLE_RECAPTCHA_SECRET')
];
