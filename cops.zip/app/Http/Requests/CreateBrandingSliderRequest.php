<?php

namespace App\Http\Requests;

use App\Models\BrandingSliders;
use Illuminate\Foundation\Http\FormRequest;

/**
 * Class CreateBrandingSliderRequest
 */
class CreateBrandingSliderRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return BrandingSliders::$rules;
    }

    /**
     * @return array|string[]
     */
    public function messages()
    {
        return [
            'branding_slider.required' => 'The image field is required.',
        ];
    }
}
