alter table `candidates` add `available_at` date null after `immediate_available`;
